﻿Imports Microsoft.VisualBasic

' The CartItem Class
' Basically a structure for holding item data
Public Class CartItem
	Implements IEquatable(Of CartItem)

#Region "Properties"

	' A place to store the quantity in the cart
	Private _quantity As Integer
	Public Property Quantity() As Integer
		Get
			Return _quantity
		End Get
		Set(ByVal value As Integer)
			_quantity = value
		End Set
	End Property

	Private _productId As Integer
	Public Property ProductId() As Integer
		Get
			Return _productId
		End Get
		Set(ByVal value As Integer)
			' To ensure that the Prod object will be re-created
			_prod = Nothing
			_productId = value
		End Set
	End Property

	Private _prod As Product = Nothing
	Public ReadOnly Property Prod() As Product
		Get
			' Lazy initialization - the object won't be created until it is needed
			If _prod Is Nothing Then
				_prod = New Product(ProductId)
			End If
			Return _prod
		End Get
	End Property

	Public ReadOnly Property Description() As String
		Get
			Return Prod.Description
		End Get
	End Property


	Public ReadOnly Property UnitPrice() As Decimal
		Get
			Return Prod.Price
		End Get
	End Property

	Public ReadOnly Property TotalPrice() As Decimal
		Get
			Return UnitPrice * Quantity
		End Get
	End Property

#End Region

	' CartItem constructor just needs a productId
	Public Sub New(ByVal productId As Integer)
		Me.ProductId = productId
	End Sub

	' Equals() - Needed to implement the IEquatable interface
	' Tests whether or not this item is equal to the parameter
	' This method is called by the Contains() method in the List class
	' We used this Contains() method in the ShoppingCart AddItem() method
	Public Overloads Function Equals(ByVal item As CartItem) As Boolean Implements IEquatable(Of CartItem).Equals
		Return item.ProductId = Me.ProductId
	End Function

End Class
