﻿
Partial Class _Default
    Inherits System.Web.UI.Page

	Protected Sub btnAddShoes_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddShirt.Click
		' Add product 1 to the shopping cart
		ShoppingCart.Instance.AddItem(1)

		' Redirect the user to view their shopping cart
		Response.Redirect("ViewCart.aspx")
	End Sub

	Protected Sub btnAddShirt_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddShorts.Click
		ShoppingCart.Instance.AddItem(2)
		Response.Redirect("ViewCart.aspx")
	End Sub

	Protected Sub btnAddPants_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddShoes.Click
		ShoppingCart.Instance.AddItem(3)
		Response.Redirect("ViewCart.aspx")
	End Sub
End Class
